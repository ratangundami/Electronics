#include<reg51.h>
#define lcd P3
 
sbit SOUND=P1^0;
sbit PUSH=P1^1;
 
sbit rs=P2^0; //register select
sbit rw=P2^1; //RW
sbit en=P2^2; //enable
unsigned char str3[10]={' ',' ',' ',' ',' ',' ',' ',' ',' ',' '}; 

void lcd_init();
void cmd(unsigned char);
void dat(unsigned char);
void delay();
void for_delay(unsigned int);
void lcd_string(char *s);
void convert(int);
 
void main()
{
    while(1)
	{
		int count=1;
		lcd_init();
    	lcd_string("CO OPEN END");
		cmd(0xc0);
		lcd_string("PROJECT");
		for_delay(10);
		while(count)
		{
			cmd(0x01);						  
			while(PUSH)
			{
				if(SOUND==1)
				{
					count++;
					delay();
					SOUND=0;
				}
			}
			delay();
			convert(count-1);
			lcd_string(str3);
			count=0;

		}
	}
}
 
void lcd_init()
{
    cmd(0x38);
    cmd(0x0F);
    cmd(0x01);
    cmd(0x80);
	delay();
}
 
void cmd(unsigned char a)
{
    lcd=a;
    rs=0;
    rw=0;
    en=1;
    delay();
    en=0;
}
 
void dat(unsigned char b)
{
    lcd=b;
    rs=1;
    rw=0;
    en=1;
    delay();
    en=0;
}
 
void lcd_string(char *s)
{
    while(*s) {
       dat(*s++);
     }
}
 
void delay()
{
    unsigned int i;
    for(i=0;i<10000;i++);
}

void for_delay(unsigned int a)
{
	int i;
	for(i=0;i<a;i++)
		delay();	
}

void convert(int num)  // Function to extract digits and send to LCD
{
	int i=0;
	while(num>0)
	{
	  	str3[i]=(num%10)+48;
  		num=num/10;
	  	i++;
	}
	str3[i]='\0';
}